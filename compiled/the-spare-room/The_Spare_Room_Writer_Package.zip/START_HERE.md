# The Spare Room writer package

22 September 2026 · Revision 3

Start with [the reading packet](compiled/the-spare-room/The_Spare_Room_Writer_Packet.pdf). It combines the writer brief, current outline, retained opening and revised middle passage.

[The cover note](COVER_NOTE.md) is available separately for the accompanying message.

Editable current material is in [stories/the-spare-room](stories/the-spare-room/README.md). The [writer brief](stories/the-spare-room/handoff/WRITER_BRIEF.md) explains the fixed constraints and the writer's freedom. The draft fragments are not a complete script and have not been timed.

The drafts and editorial folders contain historical material for optional reference. Revision 3 supersedes earlier outlines and samples. Commercial suggestions in older reviews are not verified opportunities.

MANIFEST.json records the size and SHA-256 digest of every included content file. No private machine paths, credentials, build scripts or review images are included.
